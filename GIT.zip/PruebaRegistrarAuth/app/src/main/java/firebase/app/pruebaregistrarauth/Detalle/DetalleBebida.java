package firebase.app.pruebaregistrarauth.Detalle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import firebase.app.pruebaregistrarauth.Activity.Bebidas_Activity;
import firebase.app.pruebaregistrarauth.R;
import firebase.app.pruebaregistrarauth.API.BebidasAPI;

public class DetalleBebida extends AppCompatActivity {

    private ImageView ivbannerdetalle;
    private TextView tvbannerdetalle;
    private TextView tv1bannerdetalle;
    private TextView tv2bannerdetalle;
    private TextView tv3bannerdetalle;
    private TextView tv5bannerdetalle;
    private Button btnmantenimiento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_producto);

        ivbannerdetalle = findViewById(R.id.ivbannerdetalleLIM);
        tvbannerdetalle = findViewById(R.id.tvbannerdetalleLIM);
        tv1bannerdetalle = findViewById(R.id.tv1bannerdetalleLIM);
        tv2bannerdetalle = findViewById(R.id.tv2bannerdetalleLIM);
        tv3bannerdetalle = findViewById(R.id.tv3bannerdetalleLIM);
        tv5bannerdetalle = findViewById(R.id.tv5bannerdetalleLIM);
        btnmantenimiento = findViewById(R.id.btnmantenimientoLIM);
        btnmantenimiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetalleBebida.this, Bebidas_Activity.class);
                startActivity(intent);
            }
        });

        if(getIntent().hasExtra("bebidas")) {
            BebidasAPI objCosmeticoFort = getIntent().getParcelableExtra("bebidas");
            tvbannerdetalle.setText(objCosmeticoFort.getId());
            tv1bannerdetalle.setText(objCosmeticoFort.getNombreproducto());
            tv3bannerdetalle.setText(objCosmeticoFort.getPrecioproducto());
            tv5bannerdetalle.setText(objCosmeticoFort.getDescripcion());
            //      Glide.with(context).load(objProductos.getImagen()).into(holder.ivproducto);
            Glide.with(getApplicationContext()).load(objCosmeticoFort.getImagen()).into(ivbannerdetalle);
        }

    }
}