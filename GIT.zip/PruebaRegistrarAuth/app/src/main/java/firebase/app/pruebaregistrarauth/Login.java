package firebase.app.pruebaregistrarauth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity implements View.OnClickListener {
    private ProgressBar p;
    private EditText etusuario, etpassword;
    private Button btnloginfirebase;
    private TextView t;
    private TextView tvregistrar;
    private TextView tva;

    int i = 0;
    Handler h = new Handler();
    boolean isActivo = false;
    Intent x;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        tva = findViewById(R.id.tva);
        etusuario = findViewById(R.id.etusuario);
        etpassword = findViewById(R.id.etpassword);
        btnloginfirebase = findViewById(R.id.btnloginfirebase);
        p = (ProgressBar) findViewById(R.id.progressBar);
        t = (TextView) findViewById(R.id.porcentaje);
        tvregistrar = findViewById(R.id.tvregistrar);


        btnloginfirebase.setOnClickListener(this);
        tvregistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(Login.this, RegistrarLogin.class);
                startActivity(intent2);
            }
        });

        tva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(Login.this, Menu.class);
                startActivity(intent3);
            }
        });

    }

    @Override
    public void onClick(View v) {

        if (etusuario.getText().toString() != "" &&
                etpassword.getText().toString() != "") {
            FirebaseAuth
                    .getInstance()
                    .signInWithEmailAndPassword(etusuario.getText().toString(), etpassword.getText().toString())
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                if (v.getId() == R.id.btnloginfirebase) {
                                    if (!isActivo) {
                                        Thread hilo = new Thread(new Runnable() {
                                            @Override

                                            public void run() {

                                                while (i <= 100) {
                                                    h.post(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            t.setText(i + " %");
                                                            p.setProgress(i);
                                                        }
                                                    });

                                                    try {
                                                        Thread.sleep(20);
                                                    } catch (InterruptedException e) {
                                                        e.printStackTrace();
                                                    }
                                                    if (i == 100) {

                                                        x = new Intent(Login.this, Menu.class);
                                                        startActivity(x);
                                                    }
                                                    i++;
                                                    isActivo = true;

                                                }
                                            }
                                        });
                                        hilo.start();
                                    }

                                }
                            }
                        }
                    })

                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Login.this, "Datos Incorrectos", Toast.LENGTH_SHORT).show();
                        }
                    });
        }


    }


    }

