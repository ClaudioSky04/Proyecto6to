package firebase.app.pruebaregistrarauth.API;

import android.os.Parcel;
import android.os.Parcelable;

public class AbarrotesAPI implements Parcelable {

    private String id;
    private String nombreproducto;
    private String imagen;
    private String cantidadproducto;
    private String precioproducto;
    private String precioferta;
    private String descripcion;

    public AbarrotesAPI(String id, String nombreproducto, String imagen, String cantidadproducto, String precioproducto, String precioferta, String descripcion) {
        this.id = id;
        this.nombreproducto = nombreproducto;
        this.imagen = imagen;
        this.cantidadproducto = cantidadproducto;
        this.precioproducto = precioproducto;
        this.precioferta = precioferta;
        this.descripcion = descripcion;
    }

    public static final Creator<AbarrotesAPI> CREATOR = new Creator<AbarrotesAPI>() {
        @Override
        public AbarrotesAPI createFromParcel(Parcel in) {
            return new AbarrotesAPI(in);
        }

        @Override
        public AbarrotesAPI[] newArray(int size) {
            return new AbarrotesAPI[size];
        }
    };
    protected AbarrotesAPI(Parcel in) {
        id = in.readString();
        nombreproducto = in.readString();
        imagen = in.readString();
        cantidadproducto = in.readString();
        precioproducto = in.readString();
        precioferta = in.readString();
        descripcion = in.readString();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombreproducto() {
        return nombreproducto;
    }

    public void setNombreproducto(String nombreproducto) {
        this.nombreproducto = nombreproducto;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getCantidadproducto() {
        return cantidadproducto;
    }

    public void setCantidadproducto(String cantidadproducto) {
        this.cantidadproducto = cantidadproducto;
    }

    public String getPrecioproducto() {
        return precioproducto;
    }

    public void setPrecioproducto(String precioproducto) {
        this.precioproducto = precioproducto;
    }

    public String getPrecioferta() {
        return precioferta;
    }

    public void setPrecioferta(String precioferta) {
        this.precioferta = precioferta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(nombreproducto);
        dest.writeString(imagen);
        dest.writeString(cantidadproducto);
        dest.writeString(precioproducto);
        dest.writeString(precioferta);
        dest.writeString(descripcion);
    }
}