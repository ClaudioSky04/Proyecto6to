package firebase.app.pruebaregistrarauth.API;

import android.os.Parcel;
import android.os.Parcelable;

public class BebidasAPI implements Parcelable {

    private String id;
    private String nombreproducto;
    private String imagen;
    private String precioproducto;
    private String precioferta;
    private String descripcion;

    public BebidasAPI(String id, String nombreproducto, String imagen, String precioproducto, String precioferta, String descripcion) {
        this.id = id;
        this.nombreproducto = nombreproducto;
        this.imagen = imagen;
        this.precioproducto = precioproducto;
        this.precioferta = precioferta;
        this.descripcion = descripcion;
    }

    protected BebidasAPI(Parcel in) {
        id = in.readString();
        nombreproducto = in.readString();
        imagen = in.readString();
        precioproducto = in.readString();
        precioferta = in.readString();
        descripcion = in.readString();
    }

    public static final Creator<BebidasAPI> CREATOR = new Creator<BebidasAPI>() {
        @Override
        public BebidasAPI createFromParcel(Parcel in) {
            return new BebidasAPI(in);
        }

        @Override
        public BebidasAPI[] newArray(int size) {
            return new BebidasAPI[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombreproducto() {
        return nombreproducto;
    }

    public void setNombreproducto(String nombreproducto) {
        this.nombreproducto = nombreproducto;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }


    public String getPrecioproducto() {
        return precioproducto;
    }

    public void setPrecioproducto(String precioproducto) {
        this.precioproducto = precioproducto;
    }

    public String getPrecioferta() {
        return precioferta;
    }

    public void setPrecioferta(String precioferta) {
        this.precioferta = precioferta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(nombreproducto);
        dest.writeString(imagen);
        dest.writeString(precioproducto);
        dest.writeString(precioferta);
        dest.writeString(descripcion);
    }
}
