package firebase.app.pruebaregistrarauth.Categoria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import firebase.app.pruebaregistrarauth.Adapter.BebidaAPIAdapter;
import firebase.app.pruebaregistrarauth.R;
import firebase.app.pruebaregistrarauth.API.BebidasAPI;

public class BebidasAPICategoria extends AppCompatActivity {

    private String url = "https://proyectoplazavea-85d66-default-rtdb.firebaseio.com/categoria.json";
    private RecyclerView rvproductos;
    private BebidaAPIAdapter adapter;

    private boolean puedeCargar = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bebidas_a_p_i_categoria);


        rvproductos = findViewById(R.id.rvproductos);
        adapter = new BebidaAPIAdapter(this);

        rvproductos.setAdapter(adapter);
        rvproductos.setLayoutManager(new GridLayoutManager
                (BebidasAPICategoria.this,1));
        obtenerproductos(url);
    }

    private void obtenerproductos(String urlActual) {
        RequestQueue colapeticiones = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                urlActual,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArrayProducto = response.getJSONArray("bebidas");
                            if (jsonArrayProducto.length() > 0) {
                                ArrayList<BebidasAPI> listProductos = new ArrayList<>();
                                puedeCargar = true;
                                for (int i = 1; i < jsonArrayProducto.length(); i++) {
                                    JSONObject jsonProducto = jsonArrayProducto.getJSONObject(i);
                                    listProductos.add(new BebidasAPI(
                                            jsonProducto.getString("id"),
                                            jsonProducto.getString("name"),
                                            jsonProducto.getString("image"),
                                            jsonProducto.getString("precioproducto"),
                                            jsonProducto.getString("precioferta"),
                                            jsonProducto.getString("descripcion")

                                    ));
                                }
                                adapter.agregarListapersona(listProductos);
                            }
                        } catch (JSONException ex) {
                            puedeCargar = false;
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        colapeticiones.add(jsonObjectRequest);
    }

}