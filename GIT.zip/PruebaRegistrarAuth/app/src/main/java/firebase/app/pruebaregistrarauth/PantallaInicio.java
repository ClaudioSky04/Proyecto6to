package firebase.app.pruebaregistrarauth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class PantallaInicio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_inicio);
        Intent login = new Intent(PantallaInicio.this,Login.class);
        Thread timer = new Thread(){

            @Override
            public void run() {
                try {
                    sleep(5000);
                }catch (InterruptedException ex){

                }finally {
                    startActivity(login);
                    finish();
                }
            }
        };
        timer.start();

    }


}