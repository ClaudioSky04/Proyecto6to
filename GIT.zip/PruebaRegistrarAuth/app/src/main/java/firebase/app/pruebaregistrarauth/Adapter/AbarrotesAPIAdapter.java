package firebase.app.pruebaregistrarauth.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import firebase.app.pruebaregistrarauth.Detalle.DetalleAbarrote;
import firebase.app.pruebaregistrarauth.R;
import firebase.app.pruebaregistrarauth.API.AbarrotesAPI;

public class AbarrotesAPIAdapter extends RecyclerView.Adapter<AbarrotesAPIAdapter.ViewHolder> {
    private ArrayList<AbarrotesAPI> listabarrotes;
    private Context context;

    public AbarrotesAPIAdapter(Context context) {
        this.context = context;
        listabarrotes = new ArrayList<>();
    }


    @NonNull
    @Override
    public AbarrotesAPIAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista2 = LayoutInflater.from(context)
                .inflate(R.layout.item_abarrote, parent, false);
        return new ViewHolder(vista2);
    }

    @Override
    public void onBindViewHolder(@NonNull AbarrotesAPIAdapter.ViewHolder holder, int position) {
        final AbarrotesAPI objAbarrotes = listabarrotes.get(position);
        holder.tvnombreproducto.setText(objAbarrotes.getNombreproducto());
        holder.tvprecioproducto.setText(objAbarrotes.getPrecioproducto());
        holder.tvcantidadproducto.setText(objAbarrotes.getCantidadproducto());
        holder.tvprecioferta.setText(objAbarrotes.getPrecioferta());
        holder.tvdescripcion.setText(objAbarrotes.getDescripcion());
        Glide.with(context).load(objAbarrotes.getImagen()).into(holder.ivproducto);
        holder.contenedor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentDetalleAndroid = new Intent(context, DetalleAbarrote.class);
                intentDetalleAndroid.putExtra("abarrotes", objAbarrotes);
                context.startActivity(intentDetalleAndroid);

            }

        });
    }

    public void agregarListaAbarrote(ArrayList<AbarrotesAPI> listaAbarrotes) {
        listabarrotes.addAll(listaAbarrotes);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return listabarrotes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivproducto;
        private TextView tvnombreproducto;
        private TextView tvprecioproducto;
        private TextView tvcantidadproducto;
        private TextView tvprecioferta;
        private TextView tvdescripcion;

        private CardView contenedor;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivproducto = itemView.findViewById(R.id.ivproductoABA);
            tvnombreproducto = itemView.findViewById(R.id.tvnombreproductoABA);
            tvcantidadproducto = itemView.findViewById(R.id.tvcantidadproductoABA);
            tvprecioproducto = itemView.findViewById(R.id.tvprecioproductoABA);
            tvprecioferta = itemView.findViewById(R.id.tvpreciofertaABA);
            tvdescripcion = itemView.findViewById(R.id.tvdescripcionABA);
            contenedor = itemView.findViewById(R.id.contenedorABA);
        }
    }
}
