package firebase.app.pruebaregistrarauth.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import firebase.app.pruebaregistrarauth.R;
import firebase.app.pruebaregistrarauth.model.Abarrotes;
import firebase.app.pruebaregistrarauth.model.Bebidas;

public class Bebidas_Activity extends AppCompatActivity {
    private TextView textView3;

    private List<Bebidas> listbebidas = new ArrayList<Bebidas>();
    ArrayAdapter<Bebidas> arrayAdapterBebidas;
    Bebidas bebidas ;



    private ImageView icon_add;
    private ImageView icon_save;
    private ImageView icon_delete;


    private EditText txtNombre, txtPrecio, txtPrecioferta, txtDescripcion, txtUrlImagen;

    private ListView datosbebidas;

    long maxid = 0;
    FirebaseDatabase fireDataBase;
    DatabaseReference databaseReference;

    Bebidas bebidaSeleccionada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bebidas_);

        icon_add = findViewById(R.id.icon_add);
        icon_save = findViewById(R.id.icon_save);
        icon_delete = findViewById(R.id.icon_delete);
        textView3 = findViewById(R.id.textView3);
        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Bebidas_Activity.this, Abarrotes_Activity.class);
                startActivity(intent);
            }
        });

        txtNombre = findViewById(R.id.txtNombreBEB);
        txtPrecio = findViewById(R.id.txtPrecioBEB);
        txtPrecioferta = findViewById(R.id.txtPrecioOfertaBEB);
        txtDescripcion = findViewById(R.id.txtDescripcionBEB);
        txtUrlImagen = findViewById(R.id.txtUrlImagenBEB);
        bebidas = new Bebidas();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("categoria").child("bebidas");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    maxid = (snapshot.getChildrenCount());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        datosbebidas = findViewById(R.id.datosbebida);

        //inicializarFireBase();
        listardatos();


        datosbebidas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                bebidaSeleccionada = (Bebidas) parent.getItemAtPosition(position);
                txtNombre.setText(bebidaSeleccionada.getName());
                txtPrecio.setText(bebidaSeleccionada.getPrecioproducto());
                txtPrecioferta.setText(bebidaSeleccionada.getName());
                txtUrlImagen.setText(bebidaSeleccionada.getImage());
            }
        });

        icon_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtUrlImagen.getText().toString().equals("")
                        || txtNombre.getText().toString().equals("")
                        || txtPrecio.getText().toString().equals("")
                        || txtPrecioferta.getText().toString().equals("")
                        || txtDescripcion.getText().toString().equals("")

                ) {
                    validacion();
                } else {

                    bebidas.setId(String.valueOf(maxid + 1));
                    bebidas.setName(txtNombre.getText().toString());
                    bebidas.setPrecioproducto(txtPrecio.getText().toString());
                    bebidas.setPrecioferta(txtPrecioferta.getText().toString());
                    bebidas.setDescripcion(txtDescripcion.getText().toString());
                    bebidas.setImage(txtUrlImagen.getText().toString());

                    databaseReference.child(String.valueOf(maxid + 1)).setValue(bebidas);

                    Toast.makeText(Bebidas_Activity.this, "Agregado", Toast.LENGTH_SHORT).show();
                    limpiarcajas();
                }
            }
        });

        icon_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtNombre.getText().toString().equals("")
                        || txtPrecio.getText().toString().equals("")
                        || txtPrecioferta.getText().toString().equals("")
                        || txtDescripcion.getText().toString().equals("")
                        || txtUrlImagen.getText().toString().equals("")


                ) {
                    validacion();
                } else {
                    Abarrotes pe = new Abarrotes();

                    pe.setId(bebidaSeleccionada.getId());
                    pe.setImage(txtUrlImagen.getText().toString());
                    pe.setName(txtNombre.getText().toString().trim());
                    pe.setPrecioproducto(txtPrecio.getText().toString());
                    pe.setPrecioferta(txtPrecioferta.getText().toString());
                    pe.setDescripcion(txtDescripcion.getText().toString());

                    databaseReference.child(pe.getId()).setValue(pe);
                    Toast.makeText(Bebidas_Activity.this, "Guardando", Toast.LENGTH_SHORT).show();
                    limpiarcajas();
                }
            }
        });


        icon_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtNombre.getText().toString().equals("")
                        || txtPrecio.getText().toString().equals("")
                        || txtPrecioferta.getText().toString().equals("")
                        || txtDescripcion.getText().toString().equals("")
                        || txtUrlImagen.getText().toString().equals("")
                ) {
                    validacion();
                } else {
                    Abarrotes pe = new Abarrotes();
                    pe.setId(bebidaSeleccionada.getId());
                    databaseReference.child(pe.getId()).removeValue();
                    Toast.makeText(Bebidas_Activity.this, "Eliminando", Toast.LENGTH_SHORT).show();
                    limpiarcajas();
                }
            }
        });

    }
    private void listardatos() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listbebidas.clear();
                for(DataSnapshot objSnapShot : snapshot.getChildren()){
                    Bebidas p = objSnapShot.getValue(Bebidas.class);
                    listbebidas.add(p);

                    arrayAdapterBebidas = new ArrayAdapter<Bebidas>(Bebidas_Activity.this, android.R.layout.simple_list_item_1,listbebidas);
                    datosbebidas.setAdapter(arrayAdapterBebidas);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

   /*private void inicializarFireBase() {
        FirebaseApp.initializeApp(this);
        fireDataBase = fireDataBase.getInstance();
        //fireDataBase.setPersistenceEnabled(true);
        //databaseReference = fireDataBase.getReference();
    }*/

    private void limpiarcajas() {
        txtNombre.setText("");
        txtPrecio.setText("");
        txtPrecioferta.setText("");
        txtDescripcion.setText("");
        txtUrlImagen.setText("");
    }

    private void validacion() {
        if (txtNombre.getText().toString().equals("")) {
            txtNombre.setError("Required");
        } else if (txtPrecioferta.getText().toString().equals("")) {
            txtPrecioferta.setError("Required");
        } else if (txtDescripcion.getText().toString().equals("")) {
            txtDescripcion.setError("Required");

        } else if (txtUrlImagen.getText().toString().equals("")) {
            txtUrlImagen.setError("Required");
        }
    }
}