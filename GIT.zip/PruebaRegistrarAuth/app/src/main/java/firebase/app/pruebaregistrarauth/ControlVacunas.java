package firebase.app.pruebaregistrarauth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.CheckBox;
import android.widget.Toast;

public class ControlVacunas extends AppCompatActivity implements View.OnClickListener{

    private CheckBox checkBox7, checkBox8,checkBox9,checkBox10,checkBox11,checkBox12,checkBox13,checkBox14,checkBox15,checkBox16,checkBox17,
            checkBox18;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control_vacunas);

        checkBox7 = findViewById(R.id.checkBox7);
        checkBox8 = findViewById(R.id.checkBox8);
        checkBox9 = findViewById(R.id.checkBox9);
        checkBox10= findViewById(R.id.checkBox10);
        checkBox11 = findViewById(R.id.checkBox11);
        checkBox12= findViewById(R.id.checkBox12);
        checkBox13 = findViewById(R.id.checkBox13);
        checkBox14 = findViewById(R.id.checkBox14);
        checkBox15 = findViewById(R.id.checkBox15);
        checkBox16 = findViewById(R.id.checkBox16);
        checkBox17 = findViewById(R.id.checkBox17);
        checkBox18 = findViewById(R.id.checkBox18);




        checkBox7.setOnClickListener(this);
        checkBox8.setOnClickListener(this);
        checkBox9.setOnClickListener(this);
        checkBox10.setOnClickListener(this);
        checkBox11.setOnClickListener(this);
        checkBox12.setOnClickListener(this);
        checkBox13.setOnClickListener(this);
        checkBox14.setOnClickListener(this);
        checkBox15.setOnClickListener(this);
        checkBox16.setOnClickListener(this);
        checkBox17.setOnClickListener(this);
        checkBox18.setOnClickListener(this);
    }
    @Override
    public void onClick (View v) {
        CheckBox check = null;
        switch (v.getId()) {
            case R.id. checkBox7:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "1ra Vacuna Realizada", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado Primera Vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox8:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "2d Vacuna Realizada", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado 2da vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox9:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "3ra Vacuna Realizada", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado 3ra vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox10:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "1ra Vacuna Realizada", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado primera vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox11:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "2da Vacuna Realizada", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado 2da vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox12:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "3ra Vacuna Realizada", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Ha Desmarcado 3ra vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox13:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "1ra Vacuna ", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado 1ra vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox14:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "2da Vacuna", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado 2da vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox15:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "3ra Vacuna", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado 3er vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox16:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "1ra vacuna", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado 1ra vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox17:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "2da vacuna", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado 2da Vacuna", Toast.LENGTH_LONG).show();
                } break;
            case R.id. checkBox18:
                check = (CheckBox)v;
                if (check.isChecked()) {
                    Toast.makeText(getApplicationContext(), "3ra vacuna", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Se Ha Desmarcado 3ra Vacuna", Toast.LENGTH_LONG).show();
                } break;

            default:
                Toast.makeText(getApplicationContext(), "Error! Elemento no Mapeado", Toast.LENGTH_LONG).show();
        }
    }

}