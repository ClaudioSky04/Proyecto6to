package firebase.app.pruebaregistrarauth.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import firebase.app.pruebaregistrarauth.R;
import firebase.app.pruebaregistrarauth.model.Abarrotes;

public class Abarrotes_Activity extends AppCompatActivity {
    private TextView textView3;

    private List<Abarrotes> listabarrotes = new ArrayList<Abarrotes>();
    ArrayAdapter<Abarrotes> arrayAdapterAbarrotes;
    Abarrotes abarrotes ;



    private ImageView icon_add;
    private ImageView icon_save;
    private ImageView icon_delete;


    private EditText txtNombre, txtCantidad, txtPrecio, txtPrecioferta, txtDescripcion, txtUrlImagen, txtID;

    private ListView datosabarrotes;

    long maxid = 0;
    FirebaseDatabase fireDataBase;
    DatabaseReference databaseReference;

    Abarrotes abarroteSeleccionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abarrotes_);

        icon_add = findViewById(R.id.icon_add);
        icon_save = findViewById(R.id.icon_save);
        icon_delete = findViewById(R.id.icon_delete);
        textView3 = findViewById(R.id.textView3);
        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Abarrotes_Activity.this, Bebidas_Activity.class);
                startActivity(intent);
            }
        });

        txtNombre = findViewById(R.id.txtNombreABA);
        txtPrecio = findViewById(R.id.txtPrecioABA);
        txtDescripcion = findViewById(R.id.txtDescripcionABA);
        txtUrlImagen = findViewById(R.id.txtUrlImagenABA);
        txtID = findViewById(R.id.txtID);

        abarrotes = new Abarrotes();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("categoria").child("abarrotes");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    maxid = (snapshot.getChildrenCount());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        datosabarrotes = findViewById(R.id.datosabarrotes);

        //inicializarFireBase();
        listardatos();


        datosabarrotes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               abarroteSeleccionado = (Abarrotes) parent.getItemAtPosition(position);
               txtID.setText(abarroteSeleccionado.getId());
               txtNombre.setText(abarroteSeleccionado.getName());

               txtPrecio.setText(abarroteSeleccionado.getPrecioproducto());

               txtDescripcion.setText(abarroteSeleccionado.getCantidadproducto());
               txtUrlImagen.setText(abarroteSeleccionado.getImage());
            }
        });


        icon_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (
                           txtNombre.getText().toString().equals("")
                        || txtPrecio.getText().toString().equals("")
                        || txtDescripcion.getText().toString().equals("")
                        || txtUrlImagen.getText().toString().equals("")

                ) {
                    validacion();

                } else {


                    abarrotes.setId(String.valueOf(maxid+1));;
                    abarrotes.setName(txtNombre.getText().toString());
                    abarrotes.setPrecioproducto(txtPrecio.getText().toString());
                    abarrotes.setDescripcion(txtDescripcion.getText().toString());
                    abarrotes.setImage(txtUrlImagen.getText().toString());

                    databaseReference.child(String.valueOf(maxid + 1)).setValue(abarrotes);

                    Toast.makeText(Abarrotes_Activity.this, "Agregado", Toast.LENGTH_SHORT).show();
                    limpiarcajas();
                }
            }
        });

        icon_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (       txtNombre.getText().toString().equals("")
                        || txtPrecio.getText().toString().equals("")
                        || txtDescripcion.getText().toString().equals("")
                        || txtUrlImagen.getText().toString().equals("")


                ) {
                    validacion();
                } else {
                    Abarrotes pe = new Abarrotes();

                    pe.setId(abarroteSeleccionado.getId());
                    pe.setImage(txtUrlImagen.getText().toString());
                    pe.setName(txtNombre.getText().toString().trim());
                    pe.setPrecioproducto(txtPrecio.getText().toString());
                    pe.setDescripcion(txtDescripcion.getText().toString());


                    databaseReference.child(pe.getId()).setValue(pe);
                    Toast.makeText(Abarrotes_Activity.this, "Guardando", Toast.LENGTH_SHORT).show();
                    limpiarcajas();
                }
            }
        });


        icon_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtNombre.getText().toString().equals("")
                        || txtPrecio.getText().toString().equals("")
                        || txtDescripcion.getText().toString().equals("")
                        || txtUrlImagen.getText().toString().equals("")
                ) {
                    validacion();
                } else {
                    Abarrotes pe = new Abarrotes();
                    pe.setId(abarroteSeleccionado.getId());
                    databaseReference.child(pe.getId()).setValue(pe);
                    Toast.makeText(Abarrotes_Activity.this, "Eliminando", Toast.LENGTH_SHORT).show();
                    limpiarcajas();
                }
            }
        });

    }



    private void listardatos() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listabarrotes.clear();
                for(DataSnapshot objSnapShot : snapshot.getChildren()){
                    Abarrotes p = objSnapShot.getValue(Abarrotes.class);
                    listabarrotes.add(p);

                    arrayAdapterAbarrotes = new ArrayAdapter<Abarrotes>(Abarrotes_Activity.this, android.R.layout.simple_list_item_1,listabarrotes);
                    datosabarrotes.setAdapter(arrayAdapterAbarrotes);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    /*private void inicializarFireBase() {
        FirebaseApp.initializeApp(this);
        fireDataBase = fireDataBase.getInstance();
        //fireDataBase.setPersistenceEnabled(true);
        //databaseReference = fireDataBase.getReference();
    }*/

    private void limpiarcajas() {
        txtNombre.setText("");
        txtPrecio.setText("");
        txtDescripcion.setText("");
        txtUrlImagen.setText("");
    }

    private void validacion() {
         if (txtNombre.getText().toString().equals("")) {
            txtNombre.setError("Required");
        } else if (txtPrecio.getText().toString().equals("")) {
            txtPrecio.setError("Required");
        } else if (txtDescripcion.getText().toString().equals("")) {
            txtDescripcion.setError("Required");
        } else if (txtUrlImagen.getText().toString().equals("")) {
            txtUrlImagen.setError("Required");
        }
    }
}





