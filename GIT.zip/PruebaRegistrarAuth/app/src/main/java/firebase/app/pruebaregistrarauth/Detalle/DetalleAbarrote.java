package firebase.app.pruebaregistrarauth.Detalle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import firebase.app.pruebaregistrarauth.Activity.Abarrotes_Activity;
import firebase.app.pruebaregistrarauth.R;
import firebase.app.pruebaregistrarauth.API.AbarrotesAPI;

public class DetalleAbarrote extends AppCompatActivity {

    private ImageView ivbannerdetalle;
    private TextView tvbannerdetalle;
    private TextView tv1bannerdetalle;
    private TextView tv2bannerdetalle;
    private TextView tv3bannerdetalle;
    private TextView tv4bannerdetalle;
    private TextView tv5bannerdetalle;
    private Button btnmantenimiento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_abarrote);


        ivbannerdetalle = findViewById(R.id.ivbannerdetalleABA);
        tvbannerdetalle = findViewById(R.id.tvbannerdetalleABA);
        tv1bannerdetalle = findViewById(R.id.tv1bannerdetalleABA);
        tv2bannerdetalle = findViewById(R.id.tv2bannerdetalleABA);
        tv3bannerdetalle = findViewById(R.id.tv3bannerdetalleABA);
        tv4bannerdetalle = findViewById(R.id.tv4bannerdetalleABA);
        tv5bannerdetalle = findViewById(R.id.tv5bannerdetalleABA);
        btnmantenimiento = findViewById(R.id.btnmantenimientoABA);
        btnmantenimiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetalleAbarrote.this, Abarrotes_Activity.class);
                startActivity(intent);
            }
        });

        if(getIntent().hasExtra("abarrotes")) {
            AbarrotesAPI objCosmeticoFort = getIntent().getParcelableExtra("abarrotes");
            tvbannerdetalle.setText(objCosmeticoFort.getId());
            tv1bannerdetalle.setText(objCosmeticoFort.getNombreproducto());
            tv2bannerdetalle.setText(objCosmeticoFort.getCantidadproducto());
            tv3bannerdetalle.setText(objCosmeticoFort.getPrecioproducto());
            tv4bannerdetalle.setText(objCosmeticoFort.getPrecioferta());
            tv5bannerdetalle.setText(objCosmeticoFort.getDescripcion());
            //      Glide.with(context).load(objProductos.getImagen()).into(holder.ivproducto);
            Glide.with(getApplicationContext()).load(objCosmeticoFort.getImagen()).into(ivbannerdetalle);
        }

    }
}