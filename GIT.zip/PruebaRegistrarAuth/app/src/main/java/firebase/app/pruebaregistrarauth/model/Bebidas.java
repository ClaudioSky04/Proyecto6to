package firebase.app.pruebaregistrarauth.model;

public class Bebidas {

    private String id;
    private String image;
    private String name;
    private String precioproducto;
    private String precioferta;
    private String descripcion;


    public Bebidas() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getPrecioproducto() {
        return precioproducto;
    }

    public void setPrecioproducto(String precioproducto) {
        this.precioproducto = precioproducto;
    }

    public String getPrecioferta() {
        return precioferta;
    }

    public void setPrecioferta(String precioferta) {
        this.precioferta = precioferta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return name;
    }
}
