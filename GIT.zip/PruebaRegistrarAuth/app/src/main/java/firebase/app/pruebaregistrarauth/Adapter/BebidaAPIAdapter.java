package firebase.app.pruebaregistrarauth.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import firebase.app.pruebaregistrarauth.Detalle.DetalleBebida;
import firebase.app.pruebaregistrarauth.R;
import firebase.app.pruebaregistrarauth.API.BebidasAPI;

public class BebidaAPIAdapter extends RecyclerView.Adapter<BebidaAPIAdapter.ViewHolder> {
    private ArrayList<BebidasAPI> listBebidas;
    private Context context;

    public BebidaAPIAdapter(Context context) {
        this.context = context;
        listBebidas = new ArrayList<>();
    }


    @NonNull
    @Override
    public BebidaAPIAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(context)
                .inflate(R.layout.item_producto, parent, false);
        return new ViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull BebidaAPIAdapter.ViewHolder holder, int position) {
        final BebidasAPI objBebidas = listBebidas.get(position);
        holder.tvnombreproducto.setText(objBebidas.getNombreproducto());
        holder.tvprecioproducto.setText(objBebidas.getPrecioproducto());
        holder.tvprecioferta.setText(objBebidas.getPrecioferta());
        holder.tvdescripcion.setText(objBebidas.getDescripcion());
        Glide.with(context).load(objBebidas.getImagen()).into(holder.ivproducto);
        holder.contenedor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentDetalleAndroid = new Intent(context, DetalleBebida.class);
                intentDetalleAndroid.putExtra("bebidas", objBebidas);
                context.startActivity(intentDetalleAndroid);

            }

        });
    }

    public void agregarListapersona(ArrayList<BebidasAPI> listaBebidas) {
        listBebidas.addAll(listaBebidas);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return listBebidas.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivproducto;
        private TextView tvnombreproducto;
        private TextView tvprecioproducto;
        private TextView tvprecioferta;
        private TextView tvdescripcion;

        private CardView contenedor;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivproducto = itemView.findViewById(R.id.ivproducto);
            tvnombreproducto = itemView.findViewById(R.id.tvnombremascota);
            tvprecioproducto = itemView.findViewById(R.id.tvedadmascota);
            tvprecioferta = itemView.findViewById(R.id.tvprecioferta);
            tvdescripcion = itemView.findViewById(R.id.tvdescripcion);
            contenedor = itemView.findViewById(R.id.contenedor);
        }
    }
}
