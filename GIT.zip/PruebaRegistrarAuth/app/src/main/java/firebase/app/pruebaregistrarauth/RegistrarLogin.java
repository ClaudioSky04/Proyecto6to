package firebase.app.pruebaregistrarauth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class RegistrarLogin extends AppCompatActivity {
    private EditText etname;
    private EditText etmail;
    private EditText etpass;
    private Button btnreg;

    private String name="";
    private String email ="";
    private String pass="";

    long maxid=0;



    FirebaseAuth mAuth;
    DatabaseReference mDatase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarlogin);

        mAuth = FirebaseAuth.getInstance();
        mDatase = FirebaseDatabase.getInstance().getReference();
        etname = (EditText) findViewById(R.id.etname);
        etmail = (EditText) findViewById(R.id.etmail);
        etpass = (EditText) findViewById(R.id.etpass);

        btnreg = (Button) findViewById(R.id.btnreg);


        mDatase = FirebaseDatabase.getInstance().getReference().child("Users");
        mDatase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    maxid=(snapshot.getChildrenCount());


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btnreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = etname.getText().toString();
                email = etmail.getText().toString();
                pass = etpass.getText().toString();


                if (!name.isEmpty() && !email.isEmpty() && !pass.isEmpty()) {
                    if (pass.length() >= 6) {
                        registarUser();

                    }else {
                        Toast.makeText(RegistrarLogin.this, "El pass minimo 6 letras", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(RegistrarLogin.this, "Debes completar los campos", Toast.LENGTH_SHORT).show();

                }


            }
        });

    }
    private void registarUser(){
        mAuth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){

                    Map<String,Object> map = new HashMap<>();
                    map.put("name",name);
                    map.put("email",email);
                    map.put("password",pass);

                    String id = mAuth.getCurrentUser().getUid();

                    mDatase.child(String.valueOf(maxid+1)).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task2) {
                            if(task2.isSuccessful()){
                                startActivity(new Intent(RegistrarLogin.this,Login.class));

                                finish();
                                
                            }
                            else{
                                Toast.makeText(RegistrarLogin.this,"No se crearon los datos",Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }else{
                    Toast.makeText(RegistrarLogin.this, "No se pudo Registrar este usuario", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


}