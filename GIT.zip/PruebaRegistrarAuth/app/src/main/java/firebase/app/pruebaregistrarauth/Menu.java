package firebase.app.pruebaregistrarauth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import firebase.app.pruebaregistrarauth.Categoria.AbarroteAPICategoria;
import firebase.app.pruebaregistrarauth.Categoria.BebidasAPICategoria;

public class Menu extends AppCompatActivity {

    private Button Bebidas,Lacteos,Abarrotes,Congelados,Limpieza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Bebidas = findViewById(R.id.idbebidas);
        Lacteos = findViewById(R.id.idlacteos);
        Abarrotes = findViewById(R.id.idabarrotes);
        Congelados = findViewById(R.id.idcongelados);
        Limpieza = findViewById(R.id.idlimpieza);

        Bebidas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, BebidasAPICategoria.class);
                startActivity(intent);
            }
        });
        Lacteos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(Menu.this, Consultas.class);
                startActivity(intent2);
            }
        });

        /*Abarrotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(Menu.this, AbarroteAPICategoria.class);
                startActivity(intent3);
            }
        });

        Congelados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent4 = new Intent(Menu.this, ControlVacunas.class);
                startActivity(intent4);
            }
        });*/

        /*Limpieza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent5 = new Intent(Menu.this, LimpiezaAPICategoria.class);
                startActivity(intent5);
            }
        });*/



        /*

        bebidas.setOnClickListener(this);
        dormitorio.setOnClickListener(this);
        televisor.setOnClickListener(this);
        refri.setOnClickListener(this);
        tec.setOnClickListener(this);
        cel.setOnClickListener(this);
        muebles.setOnClickListener(this);
        elec.setOnClickListener(this);
        hogar.setOnClickListener(this);
        ver.setOnClickListener(this);
        carnes.setOnClickListener(this);
        limpieza.setOnClickListener(this);
        desa.setOnClickListener(this);
    }*/
    /*
        @Override
        public void onClick(View v) {
            Intent intent = null;
            switch (v.getId()) {
                case R.id.idbebidas:
                    intent = new Intent(MenuPrincipal.this, Producto.class);
                    startActivity(intent);
                    break;
               /* case R.id.iddormitorio:
                    intent = new Intent(MainActivity.this, Dormitorios.class);
                    startActivity(intent);
                    break;
                case R.id.idtelevisores:
                    intent = new Intent(MainActivity.this, Televisores.class);
                    startActivity(intent);
                    break;
                case R.id.idrefri:
                    intent = new Intent(MainActivity.this, Refrigeracion.class);
                    startActivity(intent);
                    break;
                case R.id.idtec:
                    intent = new Intent(MainActivity.this, Tecnologias.class);
                    startActivity(intent);
                    break;
                case R.id.idcel:
                    intent = new Intent(MainActivity.this, Celulares.class);
                    startActivity(intent);
                    break;
                case R.id.idmuebles:
                    intent = new Intent(MainActivity.this, Muebles.class);
                    startActivity(intent);
                    break;
                case R.id.idelectro:
                    intent = new Intent(MainActivity.this, Electrodomesticos.class);
                    startActivity(intent);
                    break;
                case R.id.idhogar:
                    intent = new Intent(MainActivity.this, Hogar.class);
                    startActivity(intent);
                    break;
                case R.id.idfrutas:
                    intent = new Intent(MainActivity.this, VerdurasyFrutas.class);
                    startActivity(intent);
                    break;
                case R.id.idcarnes:
                    intent = new Intent(MainActivity.this, Carnes.class);
                    startActivity(intent);
                    break;
                case R.id.idlimpieza:
                    intent = new Intent(MainActivity.this, Limpieza.class);
                    startActivity(intent);
                    break;
                case R.id.iddesa:
                    intent = new Intent(MainActivity.this, Desayunos.class);
                    startActivity(intent);
                    break;*/

    }
}

