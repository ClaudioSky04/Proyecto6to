package firebase.app.pruebaregistrarauth.Categoria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import firebase.app.pruebaregistrarauth.Adapter.AbarrotesAPIAdapter;
import firebase.app.pruebaregistrarauth.R;
import firebase.app.pruebaregistrarauth.API.AbarrotesAPI;

public class AbarroteAPICategoria extends AppCompatActivity {


    private String url = "https://proyectoplazavea-85d66-default-rtdb.firebaseio.com/categoria.json";
    private RecyclerView rvabarrotes;
    private AbarrotesAPIAdapter adapter;

    private boolean puedeCargar = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abarrote_a_p_i_categoria);


        rvabarrotes = findViewById(R.id.rvabarrotes);
        adapter = new AbarrotesAPIAdapter(this);

        rvabarrotes.setAdapter(adapter);
        rvabarrotes.setLayoutManager(new GridLayoutManager
                (AbarroteAPICategoria.this,1));
        obtenerproductos(url);
    }

    private void obtenerproductos(String urlActual) {
        RequestQueue colapeticiones = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                urlActual,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArrayAbarrote = response.getJSONArray("abarrotes");
                            if (jsonArrayAbarrote.length() > 0) {
                                ArrayList<AbarrotesAPI> listabarrotes = new ArrayList<>();
                                puedeCargar = true;
                                for (int i = 1; i < jsonArrayAbarrote.length(); i++) {
                                    JSONObject jsonAbarrote = jsonArrayAbarrote.getJSONObject(i);
                                    listabarrotes.add(new AbarrotesAPI(
                                            jsonAbarrote.getString("id"),
                                            jsonAbarrote.getString("name"),
                                            jsonAbarrote.getString("image"),
                                            jsonAbarrote.getString("cantidadproducto"),
                                            jsonAbarrote.getString("precioproducto"),
                                            jsonAbarrote.getString("precioferta"),
                                            jsonAbarrote.getString("descripcion")

                                    ));
                                }
                                adapter.agregarListaAbarrote(listabarrotes);
                            }
                        } catch (JSONException ex) {
                            puedeCargar = false;
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        colapeticiones.add(jsonObjectRequest);
    }

}